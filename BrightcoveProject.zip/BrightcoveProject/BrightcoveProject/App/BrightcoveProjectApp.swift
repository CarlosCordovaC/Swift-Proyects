//
//  BrightcoveProjectApp.swift
//  BrightcoveProject
//
//  Created by Carlos Camberos Cordova on 13/06/25.
//

import SwiftUI

@main
struct BrightcoveProjectApp: App {
    var body: some Scene {
        WindowGroup {
            MainTabView()
        }
    }
}
