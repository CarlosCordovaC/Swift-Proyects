//
//  VideoViewModel.swift
//  BrightcoveProject
//
//  Created by Carlos Camberos Cordova on 13/06/25.
//

import Foundation


class VideoViewModel: ObservableObject {
    @Published var videos: [Video] = []
    @Published var errorMessage: String?

    private let service = VideoDataService()

    init() {
        loadVideos()
        
    }

    // Load Information
    func loadVideos() {
        service.fetchAccessToken { token in
            guard let token = token else {
                DispatchQueue.main.async {
                    self.errorMessage = "No se pudo obtener el token"
                }
                return
            }

            self.service.fetchVideos(token: token) { result in
                DispatchQueue.main.async {
                    switch result {
                    case .success(let videos):
                        self.videos = videos
                        
                        for (index, video) in videos.enumerated() {
                            self.service.fetchVideoSources(videoID: video.id, token: token) { src in
                                DispatchQueue.main.async {
                                    if let src = src {
                                        self.videos[index].videoURL = src
                                        print("videoURL: \(src)")
                                    }
                                }
                            }
                        }

                    case .failure(let error):
                        self.errorMessage = error.localizedDescription
                    }
                }
            }
        }
    }



    
    // ObtenerImagenes
    func fetchThumbnail(for video: Video, completion: @escaping (String?) -> Void) {
        service.fetchAccessToken { token in
            guard let token = token else {
                print("❌ No se pudo obtener el token para imagen")
                completion(nil)
                return
            }

            self.service.fetchVideoThumbnail(videoID: video.id, token: token) { url in
                DispatchQueue.main.async {
                    completion(url)
                }
            }
        }
    }

    
    // Delete Video:
    func deleteVideo(video: Video) {
        service.fetchAccessToken { token in
            guard let token = token else {
                DispatchQueue.main.async {
                    self.errorMessage = "No se pudo obtener el token"
                }
                return
            }

            self.service.deleteVideo(videoID: video.id, token: token) { result in
                DispatchQueue.main.async {
                    switch result {
                    case .success():
                        self.videos.removeAll { $0.id == video.id }
                    case .failure(let error):
                        self.errorMessage = "Error al eliminar: \(error.localizedDescription)"
                    }
                }
            }
        }
    }

    
    
    
}
