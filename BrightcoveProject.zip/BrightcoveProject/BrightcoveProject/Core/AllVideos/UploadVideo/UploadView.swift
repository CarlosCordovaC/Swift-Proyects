//
//  UploadView.swift
//  BrightcoveProject
//
//  Created by Carlos Camberos Cordova on 18/07/25.
//

import SwiftUI

struct UploadView: View {
    var body: some View {
        Text("Upload Video View")
    }
}

#Preview {
    UploadView()
}
