//
//  VideoDataService.swift
//  BrightcoveProject
//
//  Created by Carlos Camberos Cordova on 23/06/25.
//

import Foundation

class VideoDataService {
    
    private let clientId = "5b38ef71-cbd8-409d-89db-d3c32d007c54"
    private let clientSecret = "CKQak4eyVV3l7IfCG7GyUd3HFHx2-YXfDYi3z9xLw1YZDzYYw02ClxYT-Wo6DWvLKVQIf1a12h8onTy9fcEExg"

    func fetchAccessToken(completion: @escaping (String?) -> Void) {
        let credentials = "\(clientId):\(clientSecret)"
        guard let credentialsData = credentials.data(using: .utf8) else {
            completion(nil)
            return
        }

        let base64Credentials = credentialsData.base64EncodedString()

        var request = URLRequest(url: URL(string: "https://oauth.brightcove.com/v4/access_token")!)
        request.httpMethod = "POST"
        request.setValue("Basic \(base64Credentials)", forHTTPHeaderField: "Authorization")
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpBody = "grant_type=client_credentials".data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            guard
                let data = data,
                let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                let token = json["access_token"] as? String
            else {
                completion(nil)
                return
            }

            completion(token)
        }.resume()
    }

    func fetchVideos(token: String, completion: @escaping (Result<[Video], Error>) -> Void) {
        let accountId = "6415901434001"
        let urlString = "https://cms.api.brightcove.com/v1/accounts/\(accountId)/videos"
        guard let url = URL(string: urlString) else { return }

        var request = URLRequest(url: url)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard
                let data = data,
                let jsonArray = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]]
            else {
                let parseError = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to parse video data"])
                completion(.failure(parseError))
                return
            }

            //All Json info
//            if let jsonString = String(data: data, encoding: .utf8) {
//                //print("TEST JSON Response:\n\(jsonString)")
//            }

            let videos: [Video] = jsonArray.compactMap { item in
                guard let id = item["id"] as? String,
                      let accountId = item["account_id"] as? String,
                      let name = item["name"] as? String,
                      let createdAt = item["created_at"] as? String,
                      let state = item["state"] as? String,
                      let createdByDict = item["created_by"] as? [String: Any],
                      let type = createdByDict["type"] as? String,
                      let createdId = createdByDict["id"] as? String,
                      let email = createdByDict["email"] as? String
                      
                else {
                    return nil
                }
                let description = item["description"] as? String
                let tags = item["tags"] as? [String] ?? []
                let createdBy = CreatedBy(type: type, id: createdId, email: email)

                return Video(id: id, accountId: accountId, name: name, createdAt: createdAt, state:state, createdBy: createdBy, description: description, tags: tags)
            }
            
//            print("TEST Videos filtrados: \(videos)")

            completion(.success(videos))
        }.resume()
    }

    
    
    func fetchVideoThumbnail(videoID: String, token: String, completion: @escaping(String?) -> Void){
        let accountId = "6415901434001"
        let urlString = "https://cms.api.brightcove.com/v1/accounts/\(accountId)/videos/\(videoID)/images"
        
        guard let url = URL(string: urlString) else{
            print("URL invalida: \(urlString)")
            completion(nil)
            return
        }
        
        var request = URLRequest(url: url)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        
        URLSession.shared.dataTask(with: request){data, response, error in
            if let error = error{
                print("Error al obtener la imagen \(error.localizedDescription)")
                completion(nil)
                return
            }
            
            guard
                let data = data,
                let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                let poster = json["poster"] as? [String: Any],
                let thumbnailURL = poster["src"] as? String
            else{
                print("No se pudo obtener la imagen")
                completion(nil)
                return
            }
            
            print("TEST Imagen obtenida: \(thumbnailURL)")
            completion(thumbnailURL)
            
        }.resume()
    }
    
    func fetchVideoSources(videoID: String, token: String, completion: @escaping (String?) -> Void) {
        let accountId = "6415901434001"
        let urlString = "https://cms.api.brightcove.com/v1/accounts/\(accountId)/videos/\(videoID)/sources"

        guard let url = URL(string: urlString) else {
            print("❌ URL inválida: \(urlString)")
            completion(nil)
            return
        }

        var request = URLRequest(url: url)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ Error al obtener sources del video: \(error.localizedDescription)")
                completion(nil)
                return
            }

            guard
                let data = data,
                let jsonArray = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]],
                jsonArray.count >= 2
            else {
                print("⚠️ No se pudo obtener el segundo source del video \(videoID)")
                completion(nil)
                return
            }

            let secondSource = jsonArray[1]
            if let secondSrc = secondSource["src"] as? String {
                completion(secondSrc)
            } else {
                print("⚠️ El segundo source no contiene una clave 'src'")
                completion(nil)
            }

        }.resume()
    }






    
    
    
    func deleteVideo(videoID: String, token: String, completion: @escaping (Result<Void, Error>) -> Void) {
        let accountId = "6415901434001"
        let urlString = "https://cms.api.brightcove.com/v1/accounts/\(accountId)/videos/\(videoID)"
        guard let url = URL(string: urlString) else {
            print("❌ URL inválida: \(urlString)")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")

        print("📡 Enviando solicitud DELETE a: \(urlString)")

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ Error al eliminar video: \(error.localizedDescription)")
                completion(.failure(error))
                return
            }

            guard let httpResponse = response as? HTTPURLResponse else {
                print("❌ Respuesta inválida del servidor")
                completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid response"])))
                return
            }

            print("📥 Código de respuesta: \(httpResponse.statusCode)")

            if httpResponse.statusCode == 204 {
                print("✅ Video eliminado exitosamente")
                completion(.success(()))
            } else {
                let message = HTTPURLResponse.localizedString(forStatusCode: httpResponse.statusCode)
                print("⚠️ No se pudo eliminar. Código: \(httpResponse.statusCode) - \(message)")
                completion(.failure(NSError(domain: "", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: message])))
            }
        }.resume()
    }


}

