//
//  Login.swift
//  BrightcoveProject
//
//  Created by Carlos Camberos Cordova on 15/07/25.
//

import SwiftUI

struct Login: View {
    
    @State private var clientId = ""
    @State private var clientSecret = ""
    @State private var accountID = ""
    @State private var navigate = false
    
    init(clientId: String = "", clientSecret: String = "", accountID: String = "") {
        self.clientId = clientId
        self.clientSecret = clientSecret
        self.accountID = accountID
    }
    
    var body: some View {
        NavigationStack{
            VStack(){
                //Logo
                Image("Logo")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 100, height: 100)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .padding(.vertical, 32)
                
                //Test
                VStack(spacing: 32){
                    InputView(text: $clientId, title: "Client ID", placeholder: "Client ID")
                    InputView(text: $clientSecret, title: "Client Secret", placeholder: "Client Secret", isSecureField: false)
                    InputView(text: $accountID, title: "Account ID", placeholder: "##############")
                }
                
                Spacer()
                
                //LogIn Button
                buttonView(name: "Log In", color: .blue) {
                    navigate = true
                    print("Login Test Button")
                }
            }
            .padding(.bottom, 40)
            Spacer()
        }
    }
}

#Preview {
    Login()
}
