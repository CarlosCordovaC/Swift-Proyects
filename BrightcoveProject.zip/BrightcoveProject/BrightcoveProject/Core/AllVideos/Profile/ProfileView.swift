//
//  ProfileView.swift
//  BrightcoveProject
//
//  Created by Carlos Camberos Cordova on 18/07/25.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        Text("Profile View")
    }
}

#Preview {
    ProfileView()
}
