//
//  FeedViewModel.swift
//  BrightcoveProject
//
//  Created by Carlos Camberos Cordova on 04/08/25.
//

import Foundation

class FeedViewModel: ObservableObject{
    @Published var post = [Post]()
    
    let videoUrls = [
        "https://house-fastly-signed-us-east-1-prod.brightcovecdn.com/media/v1/pmp4/static/clear/6415901434001/44d08fc1-7d54-4a1d-82a8-b321d39579af/ad3a3871-b788-4e75-8507-00f9f1b777bc/main.mp4?fastly_token=Njg5MWFmN2ZfMmMxNWM5MmVkNmFmNTM4ZDNlODEyZjFlOWYzNWVkNmExZjM1NDFlZDQ3OGRlMjczNzYxODQ3MTM1ZjNiMTU5Yl8vL2hvdXNlLWZhc3RseS1zaWduZWQtdXMtZWFzdC0xLXByb2QuYnJpZ2h0Y292ZWNkbi5jb20vbWVkaWEvdjEvcG1wNC9zdGF0aWMvY2xlYXIvNjQxNTkwMTQzNDAwMS80NGQwOGZjMS03ZDU0LTRhMWQtODJhOC1iMzIxZDM5NTc5YWYvYWQzYTM4NzEtYjc4OC00ZTc1LTg1MDctMDBmOWYxYjc3N2JjL21haW4ubXA0",
        "https://house-fastly-signed-us-east-1-prod.brightcovecdn.com/media/v1/pmp4/static/clear/6415901434001/44d08fc1-7d54-4a1d-82a8-b321d39579af/ad3a3871-b788-4e75-8507-00f9f1b777bc/main.mp4?fastly_token=Njg5MWFmN2ZfMmMxNWM5MmVkNmFmNTM4ZDNlODEyZjFlOWYzNWVkNmExZjM1NDFlZDQ3OGRlMjczNzYxODQ3MTM1ZjNiMTU5Yl8vL2hvdXNlLWZhc3RseS1zaWduZWQtdXMtZWFzdC0xLXByb2QuYnJpZ2h0Y292ZWNkbi5jb20vbWVkaWEvdjEvcG1wNC9zdGF0aWMvY2xlYXIvNjQxNTkwMTQzNDAwMS80NGQwOGZjMS03ZDU0LTRhMWQtODJhOC1iMzIxZDM5NTc5YWYvYWQzYTM4NzEtYjc4OC00ZTc1LTg1MDctMDBmOWYxYjc3N2JjL21haW4ubXA0"
    ]
    
    init(){
        fetchPosts()
    }
    
    func fetchPosts(){
        self.post = [
            .init(id: NSUUID().uuidString, videoUrl: videoUrls[0]),
            .init(id: NSUUID().uuidString, videoUrl: videoUrls[1]),
        ]
    }
}
