//
//  FeedView.swift
//  BrightcoveProject
//
//  Created by Carlos Camberos Cordova on 02/08/25.
//

import SwiftUI

struct FeedView: View {
    @StateObject var viewModel = VideoViewModel()
    @State private var navigationPath = NavigationPath()

    var body: some View {
        NavigationStack(path: $navigationPath) {
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(Array(viewModel.videos.enumerated()), id: \.1.id) { index, video in
                        FeedCell(
                            video: video,
                            post: index,
                            navigationPath: $navigationPath,
                            viewModel: viewModel
                        )
                        .frame(height: UIScreen.main.bounds.height)
                    }
                }
                .scrollTargetLayout()
            }
            .scrollTargetBehavior(.paging)
            .ignoresSafeArea()
            
            .navigationDestination(for: Video.self) { video in
                VideoInfoView(
                    video: video,
                    viewModel: viewModel,
                    navigationPath: $navigationPath
                )
                .navigationBarBackButtonHidden()
            }
        }
    }
}



#Preview {
    FeedView()
}
