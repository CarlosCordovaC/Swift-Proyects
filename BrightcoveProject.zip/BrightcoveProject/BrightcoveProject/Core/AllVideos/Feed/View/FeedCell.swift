//
//  FeedCell.swift
//  BrightcoveProject
//
//  Created by Carlos Camberos Cordova on 02/08/25.
//

import SwiftUI
import AVKit

struct FeedCell: View {
    
    let video: Video
    let post: Int
    @Binding var navigationPath: NavigationPath
    @ObservedObject var viewModel: VideoViewModel
    
    var body: some View {
        ZStack{
            Rectangle()
                .fill(.blue)
                .containerRelativeFrame([.horizontal, .vertical])
                .overlay{
                    Text("Post \(post)")
                        .foregroundStyle(Color.white)
                }
            
            VStack(){
                Spacer()
                
                HStack(alignment: .bottom){
                    VStack(alignment: .leading){
                        Text("Carlos Cordova")
                            .fontWeight(.semibold)
                        
                        Button {
                        navigationPath.append(video)
                        } label: {
                            Text("Video info")
                                .fontWeight(.semibold)
                                .underline()
                        }

                        Text(video.name) 
                        
                    }
                    .foregroundStyle(Color.white)
                    .font(.subheadline)
                    Spacer()
                    
                    VStack(spacing: 28){
                        
                        Circle()
                            .frame(width: 48, height: 48)
                            .foregroundStyle(Color.gray)
                        
                        
                        Button(){
                            
                        }label: {
                            VStack(){
                                Image(systemName: "heart.fill")
                                    .resizable()
                                    .frame(width: 28, height: 28)
                                    .foregroundStyle(Color.white)
                                
                                Text("1")
                                    .font(.caption)
                                    .foregroundStyle(Color.white)
                                    .bold()
                            }
                        }
                        
                        
                        Button(){
                            
                        }label: {
                            VStack(){
                                Image(systemName: "ellipsis.bubble.fill")
                                    .resizable()
                                    .frame(width: 28, height: 28)
                                    .foregroundStyle(Color.white)
                                
                                Text("1")
                                    .font(.caption)
                                    .foregroundStyle(Color.white)
                                    .bold()
                            }
                        }
                        
                        Button(){
                            
                        }label: {
                            Image(systemName: "bookmark.fill")
                                .resizable()
                                .frame(width: 22, height: 28)
                                .foregroundStyle(Color.white)
                        }
                        
                        Button(){
                            
                        }label: {
                            Image(systemName: "arrowshape.turn.up.right.fill")
                                .resizable()
                                .frame(width: 28,height: 28)
                                .foregroundStyle(Color.white)
                        }
                        
                        
                        
                    }
                    
                }
                .padding(.bottom, 80)
                
            }
            .padding()
        }
    }
}

#Preview {
    let sampleVideo = Video(
        id: "sampleID",
        accountId: "sampleAccount",
        name: "Sample Video",
        createdAt: "2025-08-04",
        state: "ACTIVE",
        createdBy: CreatedBy(type: "user", id: "userID", email: "user@example.com"),
        description: "This is a sample description.",
        thumbnailURL: nil,
        tags: ["tag1", "tag2"]
    )
    
    return FeedCell(
        video: sampleVideo,
        post: 1,
        navigationPath: .constant(NavigationPath()),
        viewModel: VideoViewModel()
    )
}


