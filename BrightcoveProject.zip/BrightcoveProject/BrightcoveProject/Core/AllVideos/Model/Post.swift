//
//  Post.swift
//  BrightcoveProject
//
//  Created by Carlos Camberos Cordova on 04/08/25.
//

import Foundation
struct Post: Identifiable, Codable{
    let id: String
    let videoUrl: String
}
