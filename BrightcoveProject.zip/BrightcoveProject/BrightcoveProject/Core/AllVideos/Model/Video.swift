//
//  Coin.swift
//  BrightcoveProject
//
//  Created by Carlos Camberos Cordova on 23/06/25.
//
struct CreatedBy: Hashable {
    let type: String
    let id: String
    let email: String
}


struct Video: Identifiable, Hashable {
    let id: String
    let accountId: String
    let name: String
    let createdAt: String
    let state: String
    let createdBy: CreatedBy
    let description: String?
    var thumbnailURL: String? = nil
    var videoURL : String? = nil
    let tags: [String]

    static func == (lhs: Video, rhs: Video) -> Bool {
        return lhs.id == rhs.id
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}
