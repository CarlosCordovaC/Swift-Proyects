//
//  EditInfoVideoView.swift
//  BrightcoveProject
//
//  Created by Carlos Camberos Cordova on 23/07/25.
//

import SwiftUI

struct EditInfoVideoView: View {
    @Environment(\.dismiss) var dismiss
    @State private var nameEdit: String = ""
    @State private var shortDescription: String = ""
    @State private var longDescription: String = ""
    
    var body: some View {
        VStack(alignment: .leading, spacing: 26){
            ScrollView{
                
                //Title and back button
                HStack(spacing: 25){
                    Button(){
                        dismiss()
                        
                    }label: {
                        Image(systemName: "arrow.uturn.backward")
                            .font(.system(size: 20))
                            .foregroundStyle(Color(.gray))
                    }
                    Text("Edit Video Info")
                        .font(.title2)
                        .fontWeight(.semibold)
                    
                    Spacer()
                }
                .padding()
                
                Divider()
                
                VStack(alignment: .leading, spacing: 36){
                    
                    // Edit Name:
                    VStack(alignment: .leading, spacing: 12){
                        Text("Name")
                            .foregroundStyle(Color(.darkGray))
                            .fontWeight(.semibold)
                            .font(.footnote)
                        TextField("", text: $nameEdit)
                            .frame(height: 40)
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray.opacity(0.8)))
                        
                    }
                    
                    //Edit Short Description
                    VStack(alignment: .leading, spacing: 12){
                        Text("Short Description")
                            .foregroundStyle(Color(.darkGray))
                            .fontWeight(.semibold)
                            .font(.footnote)
                        TextEditor(text: $shortDescription)
                            .frame(height: 80)
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray.opacity(0.8)))
                    }
                    
                    //Edit long Description
                    VStack(alignment: .leading, spacing: 12){
                        Text("Long Description")
                            .foregroundStyle(Color(.darkGray))
                            .fontWeight(.semibold)
                            .font(.footnote)
                        TextEditor(text: $longDescription)
                            .frame(height: 150)
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray.opacity(0.8)))
                    }
                    
                    
                    Button(){
                        print("TEST Button Info")
                        
                    }label: {
                        Text("Save")
                            .font(.system(size: 18))
                            .fontWeight(.semibold)
                            .foregroundStyle(Color.white)
                            .frame(width: 120, height: 40)
                            .background(Color.blue)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                    
                    
                    
                }
                .padding()
                
            }
        }
    }
}

#Preview {
    EditInfoVideoView()
}
